#!/bin/bash
cd /opt/FedoraRemixTools
python menu.py &
exit
